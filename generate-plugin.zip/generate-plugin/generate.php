<?php
if ( ! function_exists( 'print_rr' ) ) {
	function print_rr( $content = '', $subject = null ) {
		if ( $subject ) {
			echo '<strong>' . $subject . '</strong><br>';
		}

		echo '<pre>';
		print_r( $content );
		echo '</pre>';
	}
}

if ( ! isset( $_POST ) || empty( $_POST ) ) {
	die( 'No data received.' );
}

$plugin_data = array(
	'plugin_name'            => isset( $_POST['plugin_name'] ) ? $_POST['plugin_name'] : 'My Custom Plugin',
	'plugin_description'     => isset( $_POST['plugin_description'] ) ? $_POST['plugin_description'] : 'A custom WordPress plugin.',
	'plugin_admin_css'       => isset( $_POST['plugin_admin_css'] ),
	'plugin_admin_js'        => isset( $_POST['plugin_admin_js'] ),
	'plugin_frontend_css'    => isset( $_POST['plugin_frontend_css'] ),
	'plugin_frontend_js'     => isset( $_POST['plugin_frontend_js'] ),
	'plugin_wc_support'      => isset( $_POST['plugin_wc_support'] ),
	'plugin_payment_gateway' => isset( $_POST['plugin_payment_gateway'] ),
	'payment_gateway_name'   => isset( $_POST['payment_gateway_name'] ) ? $_POST['payment_gateway_name'] : '',
	'plugin_admin_menu'      => isset( $_POST['plugin_admin_menu'] ),
	'plugin_sql_table'       => isset( $_POST['plugin_sql_table'] ),
);

$plugin_name        = trim( $plugin_data['plugin_name'] );
$plugin_description = trim( $plugin_data['plugin_description'] );
$plugin_slug        = preg_replace( '/[^a-z0-9\-]/', '-', strtolower( $plugin_name ) );
$plugin_constant    = strtoupper( str_replace( '-', '_', $plugin_slug ) );
$plugin_id          = strtolower( str_replace( '-', '_', $plugin_slug ) );
$plugin_class       = str_replace( array( ' ', '-' ), '_', $plugin_name );
$gateway_class      = str_replace( array( ' ', '-' ), '_', trim( $plugin_data['payment_gateway_name'] ) );
$gateway_slug       = preg_replace( '/[^a-z0-9\-]/', '-', strtolower( $gateway_class ) );
$gateway_id         = str_replace( '-', '_', $gateway_slug );

$plugin_dir_name = $plugin_slug . '_' . date( 'YmdHi' );
$plugin_dir_path = __DIR__ . '/plugins/' . $plugin_dir_name;
mkdir( __DIR__ . '/plugins/' . $plugin_dir_name, 0777, true );

// Save plugin data to a JSON file for reference
file_put_contents( $plugin_dir_path . '/plugin_data.json', json_encode( $plugin_data, JSON_PRETTY_PRINT ) );

$plugin_header = <<<EOD
<?php
/**
 * Plugin Name: {$plugin_name}
 * Plugin URI: https://wpstriker.com/plugins
 * Description: {$plugin_description}
 * Version: 1.0.0
 * Author: wpstriker
 * Author URI: https://wpstriker.com
 * Text Domain: {$plugin_slug}
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
EOD . PHP_EOL;

$plugin_defines = <<<EOD
define( '{$plugin_constant}_VERSION', '1.0.0' );
define( '{$plugin_constant}_FILE', __FILE__ );
define( '{$plugin_constant}_BASENAME', plugin_basename( __FILE__ ) );
define( '{$plugin_constant}_URL', untrailingslashit( plugin_dir_url( __FILE__ ) ) );
define( '{$plugin_constant}_DIR', untrailingslashit( plugin_dir_path( __FILE__ ) ) );

require_once {$plugin_constant}_DIR . '/functions.php';
EOD . PHP_EOL;

$wrapper_start = <<<EOD
class {$plugin_class} {

	protected static \$instance;

	public function __construct() {
EOD . PHP_EOL;

$init_class = '';

if ( $plugin_data['plugin_sql_table'] ) {
	$init_class .= <<<EOD
		register_activation_hook( {$plugin_constant}_FILE, array( \$this, 'install' ) );
	EOD . PHP_EOL;
}

	$init_class .= <<<EOD
		add_action( 'wp_loaded', array( \$this, 'maybe_debug' ), 20 ); 
	EOD . PHP_EOL;

if ( $plugin_data['plugin_admin_menu'] ) {
	$init_class .= <<<EOD
		add_action( 'admin_menu', array( \$this, 'add_admin_menu' ), 50 );
	EOD . PHP_EOL;
}

if ( $plugin_data['plugin_admin_css'] || $plugin_data['plugin_admin_js'] ) {
	$init_class .= <<<EOD
		add_action( 'admin_enqueue_scripts', array( \$this, 'admin_scripts' ) );
	EOD . PHP_EOL;
}

if ( $plugin_data['plugin_frontend_css'] || $plugin_data['plugin_frontend_js'] ) {
	$init_class .= <<<EOD
        add_action( 'wp_enqueue_scripts', array( \$this, 'frontend_scripts' ) );
    EOD . PHP_EOL;
}

if ( $plugin_data['plugin_wc_support'] ) {
	$init_class .= <<<EOD
        add_action( 'before_woocommerce_init', array( \$this, 'hpos_compatibility' ) );
    EOD . PHP_EOL;
}

if ( $plugin_data['plugin_payment_gateway'] ) {
	$init_class .= <<<EOD
		add_action( 'plugins_loaded', array( \$this, 'include_gateway' ), 5 );
		add_filter( 'woocommerce_payment_gateways', array( \$this, 'add_gateway' ) );
		add_action( 'woocommerce_blocks_loaded', array( \$this, 'add_wc_block_support' ) );
	EOD . PHP_EOL;
}

$init_class_end = <<<'EOD'
    }
EOD . PHP_EOL;

$class_body = '';

if ( $plugin_data['plugin_admin_menu'] ) {
	$class_body .= <<<EOD
		public function add_admin_menu() {
			add_menu_page(
				'{$plugin_name} Settings',
				'{$plugin_name} Settings',
				'administrator',
				'{$plugin_slug}-settings',
				array( \$this, '{$plugin_id}_settings_page' ),
				'dashicons-admin-generic',
				56
			);
		}

		public function {$plugin_id}_settings_page() {
			\$is_saved = false;

			if ( sipost( 'submit' ) ) {
				update_option( '{$plugin_id}_api_key', sipost( '{$plugin_id}_api_key' ) );
				\$is_saved = true;
			}
			?>
			<div class="wrap">
				<h1>{$plugin_name} Settings</h1>

				<?php if ( \$is_saved ) { ?>
					<div class="updated settings-error notice is-dismissible" style="margin: 0 0 20px; max-width: 845px;">
						<p><strong>Settings saved successfully.</strong></p>
						<button class="notice-dismiss" type="button">
							<span class="screen-reader-text">Dismiss this notice.</span>
						</button>
					</div>
				<?php } ?>

				<form method="post">
					<table class="form-table">
						<tr>
							<th scope="row"><label for="{$plugin_id}_api_key">{$plugin_name} API Key</label></th>
							<td>
								<input type="text" name="{$plugin_id}_api_key" id="{$plugin_id}_api_key" value="<?php echo get_option( '{$plugin_id}_api_key' ); ?>" class="regular-text" />
							</td>
						</tr>
					</table>
					<p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="Save"></p>
				</form>
				<div class="clear"></div>
			</div>
			<?php
		}
	EOD . PHP_EOL;
}

if ( $plugin_data['plugin_admin_css'] || $plugin_data['plugin_admin_js'] ) {
	$class_body .= <<<'EOD'
        public function admin_scripts() {
    EOD . PHP_EOL;

	if ( $plugin_data['plugin_admin_css'] ) {
		$class_body .= <<<EOD
			wp_enqueue_style( '{$plugin_slug}-admin-css', {$plugin_constant}_URL . '/assets/css/admin.css', array(), filemtime( {$plugin_constant}_DIR . '/assets/css/admin.css' ) );
		EOD . PHP_EOL;
	}

	if ( $plugin_data['plugin_admin_js'] ) {
		$class_body .= <<<EOD
			wp_enqueue_script( '{$plugin_slug}-admin-js', {$plugin_constant}_URL . '/assets/js/admin.js', array( 'jquery' ), filemtime( {$plugin_constant}_DIR . '/assets/js/admin.js' ), true );	
		EOD . PHP_EOL;
	}

	$class_body .= <<<'EOD'
        }
    EOD . PHP_EOL . PHP_EOL;
}

if ( $plugin_data['plugin_frontend_css'] || $plugin_data['plugin_frontend_js'] ) {
	$class_body .= <<<'EOD'
		public function frontend_scripts() {
	EOD . PHP_EOL;

	if ( $plugin_data['plugin_frontend_css'] ) {
		$class_body .= <<<EOD
			wp_enqueue_style( '{$plugin_slug}-frontend-css', {$plugin_constant}_URL . '/assets/css/frontend.css', array(), filemtime( {$plugin_constant}_DIR . '/assets/css/frontend.css' ) );
		EOD . PHP_EOL;
	}

	if ( $plugin_data['plugin_frontend_js'] ) {
		$class_body .= <<<EOD
			wp_enqueue_script( '{$plugin_slug}-frontend-js', {$plugin_constant}_URL . '/assets/js/frontend.js', array( 'jquery' ), filemtime( {$plugin_constant}_DIR . '/assets/js/frontend.js' ), true );	
		EOD . PHP_EOL;
	}

	$class_body .= <<<'EOD'
		}
	EOD . PHP_EOL . PHP_EOL;
}

if ( $plugin_data['plugin_wc_support'] ) {
	$class_body .= <<<EOD
		public function hpos_compatibility() {
			if ( class_exists( 'Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
				Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', {$plugin_constant}_FILE, true );
			}
		}
	EOD . PHP_EOL . PHP_EOL;
}

if ( $plugin_data['plugin_payment_gateway'] ) {
	$class_body .= <<<EOD
		public function include_gateway() {
			if ( ! class_exists( 'WC_Payment_Gateway' ) ) {
				return;
			}

			require_once {$plugin_constant}_DIR . '/includes/class-{$gateway_slug}-gateway.php';
		}

		public function add_gateway( \$methods ) {
			\$methods[] = '{$gateway_class}_Gateway';
			return \$methods;
		}

		public function add_wc_block_support() {
			if ( class_exists( 'Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) && class_exists( '{$gateway_class}_Gateway' ) ) {
				require_once {$plugin_constant}_DIR . '/includes/class-{$gateway_slug}-wc-blocks.php';
				Automattic\WooCommerce\Blocks\Payments\PaymentMethodTypeRegistry::register( new {$gateway_class}_WC_Block() );
			}
		}
	EOD . PHP_EOL;
}

$install_method = <<<EOD
	public function install() {
		global \$wpdb;
		\$collate = '';
		if ( \$wpdb->has_cap( 'collation' ) ) {
			\$collate = \$wpdb->get_charset_collate();
		}

		\$create_tables_query = 'CREATE TABLE if NOT EXISTS `' . \$wpdb->prefix . "{$plugin_slug}` (
		`id` int(11) NOT NULL AUTO_INCREMENT,
		`user_id` int(11) NOT NULL,
		`created_time` datetime NOT NULL,
		`updated_time` datetime NOT NULL, 
		PRIMARY KEY( `id` )
		) \$collate;";

		\$wpdb->query( \$create_tables_query );
	}
	EOD . PHP_EOL;

$debug_random = rand( 111, 999 );
$debug_method = <<<EOD
	public function maybe_debug() {
		if ( ! isset( \$_GET['_debug{$debug_random}'] ) ) {
			return;
		}

		die();
	}
	EOD . PHP_EOL;

$wrapper_end = <<<EOD
    public function get_log_dir( string \$handle ) {
		\$upload_dir = wp_upload_dir();
		\$log_dir    = \$upload_dir['basedir'] . '/' . \$handle . '-logs';
		wp_mkdir_p( \$log_dir );
		return \$log_dir;
	}

	public function get_log_file_name( string \$handle ) {
		if ( function_exists( 'wp_hash' ) ) {
			\$date_suffix = date( 'Y-m-d', time() );
			\$hash_suffix = wp_hash( \$handle );
			return \$this->get_log_dir( \$handle ) . '/' . sanitize_file_name( implode( '-', array( \$handle, \$date_suffix, \$hash_suffix ) ) . '.log' );
		}

		return \$this->get_log_dir( \$handle ) . '/' . \$handle . '-' . date( 'Y-m-d', time() ) . '.log';
	}

	public function log( \$message ) {
		if ( function_exists( 'wc_get_logger' ) ) {
			wc_get_logger()->debug( print_r( \$message, true ), array( 'source' => '{$plugin_slug}' ) );
		} else {
			error_log( date( '[Y-m-d H:i:s e] ' ) . print_r( \$message, true ) . PHP_EOL, 3, \$this->get_log_file_name( '{$plugin_slug}' ) );
		}
	}

	public static function get_instance() {
		if ( is_null( self::\$instance ) ) {
			self::\$instance = new self();
		}

		return self::\$instance;
	}
}

function {$plugin_class}() {
	return {$plugin_class}::get_instance();
}

{$plugin_class}();
EOD;

$payment_gateway_code = <<<EOD
<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class {$gateway_class}_Gateway extends WC_Payment_Gateway {

	public function __construct() {
		\$this->has_fields         = false;
		\$this->id                 = '{$gateway_id}';
		\$this->method_title       = _x( '{$gateway_name}', 'Payment method title', '{$plugin_slug}' );
		\$this->method_description = __( 'Accept payment using {$gateway_name} payment gateway.', '{$plugin_slug}' );

		\$this->init_form_fields();
		\$this->init_settings();

		\$this->title       = \$this->get_option( 'title' );
		\$this->description = \$this->get_option( 'description' );
		\$this->api_key     = \$this->get_option( 'api_key' );

		add_action( 'woocommerce_update_options_payment_gateways_' . \$this->id, array( \$this, 'process_admin_options' ) );
		add_action( 'woocommerce_api_wc_gateway_{$gateway_id}', array( \$this, 'process_webhook' ) );
	}

	public function init_form_fields() {
		\$this->form_fields = array(
			'enabled'     => array(
				'title'   => __( 'Enable/Disable', '{$plugin_slug}' ),
				'type'    => 'checkbox',
				'label'   => __( 'Enable {$gateway_name}', '{$plugin_slug}' ),
				'default' => 'yes',
			),
			'title'       => array(
				'title'       => __( 'Title', '{$plugin_slug}' ),
				'type'        => 'text',
				'description' => __( 'This controls the title which the user sees during checkout.', '{$plugin_slug}' ),
				'default'     => __( '{$gateway_name}', '{$plugin_slug}' ),
				'desc_tip'    => true,
			),
			'description' => array(
				'title'       => __( 'Description', '{$plugin_slug}' ),
				'type'        => 'textarea',
				'description' => __( 'Payment method description that the customer will see on your checkout.', '{$plugin_slug}' ),
				'default'     => __( 'Secure and irreversible payments via {$gateway_name}.', '{$plugin_slug}' ),
				'desc_tip'    => true,
			),
			'api_key'     => array(
				'title'       => __( 'API Key', '{$plugin_slug}' ),
				'type'        => 'text',
				'description' => __( 'Please enter your API Key', '{$plugin_slug}' ),
				'default'     => '',
				'desc_tip'    => true,
				'placeholder' => 'XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX',
			),
		);
	}

	public function process_payment( \$order_id ) {
		\$order = wc_get_order( \$order_id );

		return array(
			'result'   => 'success',
			'redirect' => \$order->order_received_url(),
		);
	}

	public function process_webhook() {
		// Retrieve the request's body and parse it as JSON.
	}
}
EOD;

$payment_gateway_blocks_code = <<<EOD
<?php
use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class {$gateway_class}_WC_Block extends AbstractPaymentMethodType {

	private \$gateway;

	protected \$name = '{$gateway_id}';

	public function initialize() {
		\$this->settings = get_option( 'woocommerce_{$gateway_id}_settings', array() );
		\$gateways       = WC()->payment_gateways->payment_gateways();
		\$this->gateway  = isset( \$gateways[ \$this->name ] ) ? \$gateways[ \$this->name ] : null;
	}

	public function is_active() {
		return isset( \$this->gateway ) && \$this->gateway->is_available();
	}

	public function get_payment_method_script_handles() {
		wp_register_script(
			'wc-{$gateway_slug}-payments-blocks',
			{$plugin_constant}_URL . '/assets/js/{$gateway_slug}-wc-block.js',
			array(
				'wc-blocks-registry',
				'wc-settings',
				'wp-element',
				'wp-html-entities',
				'wp-i18n',
			),
			filemtime( {$plugin_constant}_DIR . '/assets/js/{$gateway_slug}-wc-block.js' ),
			true
		);

		return array( 'wc-{$gateway_slug}-payments-blocks' );
	}

	public function get_payment_method_data() {
		return array(
			'title'       => \$this->get_setting( 'title' ),
			'description' => \$this->get_setting( 'description' ),
			'supports'    => array_filter( \$this->gateway->supports, array( \$this->gateway, 'supports' ) ),
		);
	}
}
EOD;

$gateway_block_code = <<<EOD
const {$gateway_id}_settings = window.wc.wcSettings.getSetting('{$gateway_id}_data', {});
const {$gateway_id}_label = window.wp.htmlEntities.decodeEntities({$gateway_id}_settings.title) || window.wp.i18n.__('{$gateway_name}', '{$plugin_slug}');
const {$gateway_id}_Content = () => {
    return window.wp.htmlEntities.decodeEntities({$gateway_id}_settings.description || '');
};

const {$gateway_class}_Block_Gateway = {
    name: '{$gateway_id}',
    label: {$gateway_id}_label,
    content: Object(window.wp.element.createElement)({$gateway_id}_Content, null),
    edit: Object(window.wp.element.createElement)({$gateway_id}_Content, null),
    canMakePayment: () => true,
    ariaLabel: {$gateway_id}_label,
    supports: {
        features: {$gateway_id}_settings.supports,
    },
};
window.wc.wcBlocksRegistry.registerPaymentMethod({$gateway_class}_Block_Gateway);
EOD;

// Create main plugin file
$plugin_final_dir = $plugin_dir_path . '/' . $plugin_slug;

mkdir( $plugin_final_dir, 0777, true );

$file_content = $plugin_header . PHP_EOL . $plugin_defines . PHP_EOL . $wrapper_start . $init_class . $init_class_end . PHP_EOL . $class_body . PHP_EOL . ( $plugin_data['plugin_sql_table'] ? $install_method : '' ) . PHP_EOL . $debug_method . PHP_EOL . $wrapper_end;
file_put_contents( $plugin_final_dir . '/' . $plugin_slug . '.php', $file_content );

if ( $plugin_data['plugin_admin_css'] || $plugin_data['plugin_frontend_css'] ) {
	if ( ! is_dir( $plugin_final_dir . '/assets' ) ) {
		mkdir( $plugin_final_dir . '/assets', 0777, true );
	}
	if ( ! is_dir( $plugin_final_dir . '/assets/css' ) ) {
		mkdir( $plugin_final_dir . '/assets/css', 0777, true );
	}
}

if ( $plugin_data['plugin_admin_js'] || $plugin_data['plugin_frontend_js'] || $plugin_data['plugin_payment_gateway'] ) {
	if ( ! is_dir( $plugin_final_dir . '/assets' ) ) {
		mkdir( $plugin_final_dir . '/assets', 0777, true );
	}
	if ( ! is_dir( $plugin_final_dir . '/assets/js' ) ) {
		mkdir( $plugin_final_dir . '/assets/js', 0777, true );
	}
}

if ( $plugin_data['plugin_admin_css'] ) {
	file_put_contents( $plugin_final_dir . '/assets/css/admin.css', "/* Admin CSS */\n" );
}

if ( $plugin_data['plugin_admin_js'] ) {
	file_put_contents( $plugin_final_dir . '/assets/js/admin.js', "// Admin JS\n" );
}

if ( $plugin_data['plugin_frontend_css'] ) {
	file_put_contents( $plugin_final_dir . '/assets/css/frontend.css', "/* Frontend CSS */\n" );
}

if ( $plugin_data['plugin_frontend_js'] ) {
	file_put_contents( $plugin_final_dir . '/assets/js/frontend.js', "// Frontend JS\n" );
}

if ( $plugin_data['plugin_payment_gateway'] ) {
	mkdir( $plugin_final_dir . '/includes', 0777, true );
	file_put_contents( $plugin_final_dir . '/includes/class-' . $gateway_slug . '-gateway.php', $payment_gateway_code );
	file_put_contents( $plugin_final_dir . '/includes/class-' . $gateway_slug . '-wc-blocks.php', $payment_gateway_blocks_code );
	file_put_contents( $plugin_final_dir . '/assets/js/' . $gateway_slug . '-wc-block.js', $gateway_block_code );
}

// insert function file
copy( __DIR__ . '/functions.php', $plugin_final_dir . '/functions.php' );

// Get real path for our folder
$rootPath = realpath( $plugin_final_dir );

// Initialize archive object
$zip = new ZipArchive();
$zip->open( $plugin_dir_path . '/' . $plugin_slug . '.zip', ZipArchive::CREATE | ZipArchive::OVERWRITE );

// Create recursive directory iterator
$files = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $rootPath ), RecursiveIteratorIterator::LEAVES_ONLY );

foreach ( $files as $name => $file ) {
	// Skip directories (they would be added automatically)
	if ( ! $file->isDir() ) {
		// Get real and relative path for current file
		$filePath     = $file->getRealPath();
		$relativePath = substr( $filePath, strlen( $rootPath ) + 1 );

		// Add current file to archive
		$zip->addFile( $filePath, $relativePath );
	}
}

// Zip archive will be created only after closing object
$zip->close();

ob_clean();
header( 'Location: download.php?generated=1&plugin_dir=' . urlencode( $plugin_dir_name ) . '&plugin_slug=' . urlencode( $plugin_slug ) );
die();
