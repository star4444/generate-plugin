const plugin_payment_gateway = document.getElementById('plugin_payment_gateway');
plugin_payment_gateway.addEventListener('click', function (event) {
    if (this.checked) {
        document.querySelectorAll('.gateway_name_block').forEach(el => el.classList.remove('hidden'));
    } else {
        document.querySelectorAll('.gateway_name_block').forEach(el => el.classList.add('hidden'));
    }
});