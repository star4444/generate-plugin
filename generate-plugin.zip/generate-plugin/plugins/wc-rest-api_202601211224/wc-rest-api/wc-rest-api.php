<?php
/**
 * Plugin Name: WC REST API
 * Plugin URI: https://wpstriker.com/plugins
 * Description: Plugin for WC REST API
 * Version: 1.0.0
 * Author: wpstriker
 * Author URI: https://wpstriker.com
 * Text Domain: wc-rest-api
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

define( 'WC_REST_API_VERSION', '1.0.0' );
define( 'WC_REST_API_FILE', __FILE__ );
define( 'WC_REST_API_BASENAME', plugin_basename( __FILE__ ) );
define( 'WC_REST_API_URL', untrailingslashit( plugin_dir_url( __FILE__ ) ) );
define( 'WC_REST_API_DIR', untrailingslashit( plugin_dir_path( __FILE__ ) ) );

require_once WC_REST_API_DIR . '/functions.php';

class WC_REST_API {

	protected static $instance;

	public function __construct() {
		add_action( 'wp_loaded', array( $this, 'maybe_debug' ), 20 );    
    add_action( 'before_woocommerce_init', array( $this, 'hpos_compatibility' ) );
    }

	public function hpos_compatibility() {
		if ( class_exists( 'Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', WC_REST_API_FILE, true );
		}
	}


    public function maybe_debug() {
        if ( ! isset( $_GET['_debug209'] ) ) {
            return;
        }

        die();
    }

    public function get_log_dir( string $handle ) {
		$upload_dir = wp_upload_dir();
		$log_dir    = $upload_dir['basedir'] . '/' . $handle . '-logs';
		wp_mkdir_p( $log_dir );
		return $log_dir;
	}

	public function get_log_file_name( string $handle ) {
		if ( function_exists( 'wp_hash' ) ) {
			$date_suffix = date( 'Y-m-d', time() );
			$hash_suffix = wp_hash( $handle );
			return $this->get_log_dir( $handle ) . '/' . sanitize_file_name( implode( '-', array( $handle, $date_suffix, $hash_suffix ) ) . '.log' );
		}

		return $this->get_log_dir( $handle ) . '/' . $handle . '-' . date( 'Y-m-d', time() ) . '.log';
	}

	public function log( $message ) {
		if ( function_exists( 'wc_get_logger' ) ) {
			wc_get_logger()->debug( print_r( $message, true ), array( 'source' => 'wc-rest-api' ) );
		} else {
			error_log( date( '[Y-m-d H:i:s e] ' ) . print_r( $message, true ) . PHP_EOL, 3, $this->get_log_file_name( 'wc-rest-api' ) );
		}
	}

	public static function get_instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}
}

function WC_REST_API() {
	return WC_REST_API::get_instance();
}

WC_REST_API();