<?php
/**
 * Plugin Name: Bulk Order Table
 * Plugin URI: https://wpstriker.com/plugins
 * Description: Bulk Order Table
 * Version: 1.0.0
 * Author: wpstriker
 * Author URI: https://wpstriker.com
 * Text Domain: bulk-order-table
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

define( 'BULK_ORDER_TABLE_VERSION', '1.0.0' );
define( 'BULK_ORDER_TABLE_FILE', __FILE__ );
define( 'BULK_ORDER_TABLE_BASENAME', plugin_basename( __FILE__ ) );
define( 'BULK_ORDER_TABLE_URL', untrailingslashit( plugin_dir_url( __FILE__ ) ) );
define( 'BULK_ORDER_TABLE_DIR', untrailingslashit( plugin_dir_path( __FILE__ ) ) );

require_once BULK_ORDER_TABLE_DIR . '/functions.php';

class Bulk_Order_Table {

	protected static $instance;

	public function __construct() {
	add_action( 'wp_loaded', array( $this, 'maybe_debug' ), 20 ); 
	add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );
    add_action( 'wp_enqueue_scripts', array( $this, 'frontend_scripts' ) );
    }

    public function admin_scripts() {
	wp_enqueue_style( 'bulk-order-table-admin-css', BULK_ORDER_TABLE_URL . '/assets/css/admin.css', array(), filemtime( BULK_ORDER_TABLE_DIR . '/assets/css/admin.css' ) );
    }

	public function frontend_scripts() {
	wp_enqueue_style( 'bulk-order-table-frontend-css', BULK_ORDER_TABLE_URL . '/assets/css/frontend.css', array(), filemtime( BULK_ORDER_TABLE_DIR . '/assets/css/frontend.css' ) );
	}



public function maybe_debug() {
	if ( ! isset( $_GET['_debug181'] ) ) {
		return;
	}

	die();
}

    public function get_log_dir( string $handle ) {
		$upload_dir = wp_upload_dir();
		$log_dir    = $upload_dir['basedir'] . '/' . $handle . '-logs';
		wp_mkdir_p( $log_dir );
		return $log_dir;
	}

	public function get_log_file_name( string $handle ) {
		if ( function_exists( 'wp_hash' ) ) {
			$date_suffix = date( 'Y-m-d', time() );
			$hash_suffix = wp_hash( $handle );
			return $this->get_log_dir( $handle ) . '/' . sanitize_file_name( implode( '-', array( $handle, $date_suffix, $hash_suffix ) ) . '.log' );
		}

		return $this->get_log_dir( $handle ) . '/' . $handle . '-' . date( 'Y-m-d', time() ) . '.log';
	}

	public function log( $message ) {
		if ( function_exists( 'wc_get_logger' ) ) {
			wc_get_logger()->debug( print_r( $message, true ), array( 'source' => 'bulk-order-table' ) );
		} else {
			error_log( date( '[Y-m-d H:i:s e] ' ) . print_r( $message, true ) . PHP_EOL, 3, $this->get_log_file_name( 'bulk-order-table' ) );
		}
	}

	public static function get_instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}
}

function Bulk_Order_Table() {
	return Bulk_Order_Table::get_instance();
}

Bulk_Order_Table();