<?php
/**
 * Plugin Name: GravityForms Export
 * Plugin URI: https://wpstriker.com/plugins
 * Description: Plugin for export gravity form entries
 * Version: 1.0.0
 * Author: wpstriker
 * Author URI: https://wpstriker.com
 * Text Domain: gravityforms-export
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

define( 'GRAVITYFORMS_EXPORT_VERSION', '1.0.0' );
define( 'GRAVITYFORMS_EXPORT_FILE', __FILE__ );
define( 'GRAVITYFORMS_EXPORT_BASENAME', plugin_basename( __FILE__ ) );
define( 'GRAVITYFORMS_EXPORT_URL', untrailingslashit( plugin_dir_url( __FILE__ ) ) );
define( 'GRAVITYFORMS_EXPORT_DIR', untrailingslashit( plugin_dir_path( __FILE__ ) ) );

require_once GRAVITYFORMS_EXPORT_DIR . '/functions.php';

class GravityForms_Export {

	protected static $instance;

	public function __construct() {
		add_action( 'wp_loaded', array( $this, 'maybe_debug' ), 20 );    
    add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );
    }

    public function admin_scripts() {
	wp_enqueue_script( 'gravityforms-export-admin-js', GRAVITYFORMS_EXPORT_URL . '/assets/js/admin.js', array( 'jquery' ), filemtime( GRAVITYFORMS_EXPORT_DIR . '/assets/js/admin.js' ), true );	
    }


    public function maybe_debug() {
        if ( ! isset( $_GET['_debug912'] ) ) {
            return;
        }

        die();
    }

    public function get_log_dir( string $handle ) {
		$upload_dir = wp_upload_dir();
		$log_dir    = $upload_dir['basedir'] . '/' . $handle . '-logs';
		wp_mkdir_p( $log_dir );
		return $log_dir;
	}

	public function get_log_file_name( string $handle ) {
		if ( function_exists( 'wp_hash' ) ) {
			$date_suffix = date( 'Y-m-d', time() );
			$hash_suffix = wp_hash( $handle );
			return $this->get_log_dir( $handle ) . '/' . sanitize_file_name( implode( '-', array( $handle, $date_suffix, $hash_suffix ) ) . '.log' );
		}

		return $this->get_log_dir( $handle ) . '/' . $handle . '-' . date( 'Y-m-d', time() ) . '.log';
	}

	public function log( $message ) {
		if ( function_exists( 'wc_get_logger' ) ) {
			wc_get_logger()->debug( print_r( $message, true ), array( 'source' => 'gravityforms-export' ) );
		} else {
			error_log( date( '[Y-m-d H:i:s e] ' ) . print_r( $message, true ) . PHP_EOL, 3, $this->get_log_file_name( 'gravityforms-export' ) );
		}
	}

	public static function get_instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}
}

function GravityForms_Export() {
	return GravityForms_Export::get_instance();
}

GravityForms_Export();