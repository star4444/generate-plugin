<?php
use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class Sample_WC_Block extends AbstractPaymentMethodType {

	private $gateway;

	protected $name = 'sample';

	public function initialize() {
		$this->settings = get_option( 'woocommerce_sample_settings', array() );
		$gateways       = WC()->payment_gateways->payment_gateways();
		$this->gateway  = isset( $gateways[ $this->name ] ) ? $gateways[ $this->name ] : null;
	}

	public function is_active() {
		return isset( $this->gateway ) && $this->gateway->is_available();
	}

	public function get_payment_method_script_handles() {
		wp_register_script(
			'wc-sample-payments-blocks',
			SAMPLE_PLUGIN_URL . '/assets/js/sample-wc-block.js',
			array(
				'wc-blocks-registry',
				'wc-settings',
				'wp-element',
				'wp-html-entities',
				'wp-i18n',
			),
			filemtime( SAMPLE_PLUGIN_DIR . '/assets/js/sample-wc-block.js' ),
			true
		);

		return array( 'wc-sample-payments-blocks' );
	}

	public function get_payment_method_data() {
		return array(
			'title'       => $this->get_setting( 'title' ),
			'description' => $this->get_setting( 'description' ),
			'supports'    => array_filter( $this->gateway->supports, array( $this->gateway, 'supports' ) ),
		);
	}
}