<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Sample_Gateway extends WC_Payment_Gateway {

	public function __construct() {
		$this->has_fields         = false;
		$this->id                 = 'sample';
		$this->method_title       = _x( '', 'Payment method title', 'sample-plugin' );
		$this->method_description = __( 'Accept payment using  payment gateway.', 'sample-plugin' );

		$this->init_form_fields();
		$this->init_settings();

		$this->title       = $this->get_option( 'title' );
		$this->description = $this->get_option( 'description' );
		$this->api_key     = $this->get_option( 'api_key' );

		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
		add_action( 'woocommerce_api_wc_gateway_sample', array( $this, 'process_webhook' ) );
	}

	public function init_form_fields() {
		$this->form_fields = array(
			'enabled'     => array(
				'title'   => __( 'Enable/Disable', 'sample-plugin' ),
				'type'    => 'checkbox',
				'label'   => __( 'Enable ', 'sample-plugin' ),
				'default' => 'yes',
			),
			'title'       => array(
				'title'       => __( 'Title', 'sample-plugin' ),
				'type'        => 'text',
				'description' => __( 'This controls the title which the user sees during checkout.', 'sample-plugin' ),
				'default'     => __( '', 'sample-plugin' ),
				'desc_tip'    => true,
			),
			'description' => array(
				'title'       => __( 'Description', 'sample-plugin' ),
				'type'        => 'textarea',
				'description' => __( 'Payment method description that the customer will see on your checkout.', 'sample-plugin' ),
				'default'     => __( 'Secure and irreversible payments via .', 'sample-plugin' ),
				'desc_tip'    => true,
			),
			'api_key'     => array(
				'title'       => __( 'API Key', 'sample-plugin' ),
				'type'        => 'text',
				'description' => __( 'Please enter your API Key', 'sample-plugin' ),
				'default'     => '',
				'desc_tip'    => true,
				'placeholder' => 'XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX',
			),
		);
	}

	public function process_payment( $order_id ) {
		$order = wc_get_order( $order_id );

		return array(
			'result'   => 'success',
			'redirect' => $order->order_received_url(),
		);
	}

	public function process_webhook() {
		// Retrieve the request's body and parse it as JSON.
	}
}