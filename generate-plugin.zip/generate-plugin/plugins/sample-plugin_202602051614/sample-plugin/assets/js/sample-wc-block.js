const sample_settings = window.wc.wcSettings.getSetting('sample_data', {});
const sample_label = window.wp.htmlEntities.decodeEntities(sample_settings.title) || window.wp.i18n.__('', 'sample-plugin');
const sample_Content = () => {
    return window.wp.htmlEntities.decodeEntities(sample_settings.description || '');
};

const Sample_Block_Gateway = {
    name: 'sample',
    label: sample_label,
    content: Object(window.wp.element.createElement)(sample_Content, null),
    edit: Object(window.wp.element.createElement)(sample_Content, null),
    canMakePayment: () => true,
    ariaLabel: sample_label,
    supports: {
        features: sample_settings.supports,
    },
};
window.wc.wcBlocksRegistry.registerPaymentMethod(Sample_Block_Gateway);