<?php
/**
 * Plugin Name: Sample Plugin
 * Plugin URI: https://wpstriker.com/plugins
 * Description: Plugin Sample
 * Version: 1.0.0
 * Author: wpstriker
 * Author URI: https://wpstriker.com
 * Text Domain: sample-plugin
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

define( 'SAMPLE_PLUGIN_VERSION', '1.0.0' );
define( 'SAMPLE_PLUGIN_FILE', __FILE__ );
define( 'SAMPLE_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
define( 'SAMPLE_PLUGIN_URL', untrailingslashit( plugin_dir_url( __FILE__ ) ) );
define( 'SAMPLE_PLUGIN_DIR', untrailingslashit( plugin_dir_path( __FILE__ ) ) );

require_once SAMPLE_PLUGIN_DIR . '/functions.php';

class Sample_Plugin {

	protected static $instance;

	public function __construct() {
		add_action( 'wp_loaded', array( $this, 'maybe_debug' ), 20 );    
    add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );
    add_action( 'wp_enqueue_scripts', array( $this, 'frontend_scripts' ) );
    add_action( 'before_woocommerce_init', array( $this, 'hpos_compatibility' ) );
    }

    public function admin_scripts() {
	wp_enqueue_style( 'sample-plugin-admin-css', SAMPLE_PLUGIN_URL . '/assets/css/admin.css', array(), filemtime( SAMPLE_PLUGIN_DIR . '/assets/css/admin.css' ) );
	wp_enqueue_script( 'sample-plugin-admin-js', SAMPLE_PLUGIN_URL . '/assets/js/admin.js', array( 'jquery' ), filemtime( SAMPLE_PLUGIN_DIR . '/assets/js/admin.js' ), true );	
    }

	public function frontend_scripts() {
	wp_enqueue_style( 'sample-plugin-frontend-css', SAMPLE_PLUGIN_URL . '/assets/css/frontend.css', array(), filemtime( SAMPLE_PLUGIN_DIR . '/assets/css/frontend.css' ) );
	wp_enqueue_script( 'sample-plugin-frontend-js', SAMPLE_PLUGIN_URL . '/assets/js/frontend.js', array( 'jquery' ), filemtime( SAMPLE_PLUGIN_DIR . '/assets/js/frontend.js' ), true );	
	}

	public function hpos_compatibility() {
		if ( class_exists( 'Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', SAMPLE_PLUGIN_FILE, true );
		}
	}


    public function maybe_debug() {
        if ( ! isset( $_GET['_debug584'] ) ) {
            return;
        }

        die();
    }

    public function get_log_dir( string $handle ) {
		$upload_dir = wp_upload_dir();
		$log_dir    = $upload_dir['basedir'] . '/' . $handle . '-logs';
		wp_mkdir_p( $log_dir );
		return $log_dir;
	}

	public function get_log_file_name( string $handle ) {
		if ( function_exists( 'wp_hash' ) ) {
			$date_suffix = date( 'Y-m-d', time() );
			$hash_suffix = wp_hash( $handle );
			return $this->get_log_dir( $handle ) . '/' . sanitize_file_name( implode( '-', array( $handle, $date_suffix, $hash_suffix ) ) . '.log' );
		}

		return $this->get_log_dir( $handle ) . '/' . $handle . '-' . date( 'Y-m-d', time() ) . '.log';
	}

	public function log( $message ) {
		if ( function_exists( 'wc_get_logger' ) ) {
			wc_get_logger()->debug( print_r( $message, true ), array( 'source' => 'sample-plugin' ) );
		} else {
			error_log( date( '[Y-m-d H:i:s e] ' ) . print_r( $message, true ) . PHP_EOL, 3, $this->get_log_file_name( 'sample-plugin' ) );
		}
	}

	public static function get_instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}
}

function Sample_Plugin() {
	return Sample_Plugin::get_instance();
}

Sample_Plugin();