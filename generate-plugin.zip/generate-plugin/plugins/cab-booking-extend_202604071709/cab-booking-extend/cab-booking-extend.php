<?php
/**
 * Plugin Name: Cab Booking Extend
 * Plugin URI: https://wpstriker.com/plugins
 * Description: Cab Booking Extend
 * Version: 1.0.0
 * Author: wpstriker
 * Author URI: https://wpstriker.com
 * Text Domain: cab-booking-extend
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

define( 'CAB_BOOKING_EXTEND_VERSION', '1.0.0' );
define( 'CAB_BOOKING_EXTEND_FILE', __FILE__ );
define( 'CAB_BOOKING_EXTEND_BASENAME', plugin_basename( __FILE__ ) );
define( 'CAB_BOOKING_EXTEND_URL', untrailingslashit( plugin_dir_url( __FILE__ ) ) );
define( 'CAB_BOOKING_EXTEND_DIR', untrailingslashit( plugin_dir_path( __FILE__ ) ) );

require_once CAB_BOOKING_EXTEND_DIR . '/functions.php';

class Cab_Booking_Extend {

	protected static $instance;

	public function __construct() {
	add_action( 'wp_loaded', array( $this, 'maybe_debug' ), 20 ); 
    }



public function maybe_debug() {
	if ( ! isset( $_GET['_debug854'] ) ) {
		return;
	}

	die();
}

    public function get_log_dir( string $handle ) {
		$upload_dir = wp_upload_dir();
		$log_dir    = $upload_dir['basedir'] . '/' . $handle . '-logs';
		wp_mkdir_p( $log_dir );
		return $log_dir;
	}

	public function get_log_file_name( string $handle ) {
		if ( function_exists( 'wp_hash' ) ) {
			$date_suffix = date( 'Y-m-d', time() );
			$hash_suffix = wp_hash( $handle );
			return $this->get_log_dir( $handle ) . '/' . sanitize_file_name( implode( '-', array( $handle, $date_suffix, $hash_suffix ) ) . '.log' );
		}

		return $this->get_log_dir( $handle ) . '/' . $handle . '-' . date( 'Y-m-d', time() ) . '.log';
	}

	public function log( $message ) {
		if ( function_exists( 'wc_get_logger' ) ) {
			wc_get_logger()->debug( print_r( $message, true ), array( 'source' => 'cab-booking-extend' ) );
		} else {
			error_log( date( '[Y-m-d H:i:s e] ' ) . print_r( $message, true ) . PHP_EOL, 3, $this->get_log_file_name( 'cab-booking-extend' ) );
		}
	}

	public static function get_instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}
}

function Cab_Booking_Extend() {
	return Cab_Booking_Extend::get_instance();
}

Cab_Booking_Extend();