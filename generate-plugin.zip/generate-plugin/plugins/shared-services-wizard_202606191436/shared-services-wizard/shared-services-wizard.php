<?php
/**
 * Plugin Name: Shared Services Wizard
 * Plugin URI: https://wpstriker.com/plugins
 * Description: Plugin for Shared Services Wizard
 * Version: 1.0.0
 * Author: wpstriker
 * Author URI: https://wpstriker.com
 * Text Domain: shared-services-wizard
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

define( 'SHARED_SERVICES_WIZARD_VERSION', '1.0.0' );
define( 'SHARED_SERVICES_WIZARD_FILE', __FILE__ );
define( 'SHARED_SERVICES_WIZARD_BASENAME', plugin_basename( __FILE__ ) );
define( 'SHARED_SERVICES_WIZARD_URL', untrailingslashit( plugin_dir_url( __FILE__ ) ) );
define( 'SHARED_SERVICES_WIZARD_DIR', untrailingslashit( plugin_dir_path( __FILE__ ) ) );

require_once SHARED_SERVICES_WIZARD_DIR . '/functions.php';

class Shared_Services_Wizard {

	protected static $instance;

	public function __construct() {
	register_activation_hook( SHARED_SERVICES_WIZARD_FILE, array( $this, 'install' ) );
	add_action( 'wp_loaded', array( $this, 'maybe_debug' ), 20 ); 
	add_action( 'admin_menu', array( $this, 'add_admin_menu' ), 50 );
	add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );
    add_action( 'wp_enqueue_scripts', array( $this, 'frontend_scripts' ) );
    add_action( 'before_woocommerce_init', array( $this, 'hpos_compatibility' ) );
    }

	public function add_admin_menu() {
		add_menu_page(
			'Shared Services Wizard Settings',
			'Shared Services Wizard Settings',
			'administrator',
			'shared-services-wizard-settings',
			array( $this, 'shared_services_wizard_settings_page' ),
			'dashicons-admin-generic',
			56
		);
	}

	public function shared_services_wizard_settings_page() {
		$is_saved = false;

		if ( sipost( 'submit' ) ) {
			update_option( 'shared_services_wizard_api_key', sipost( 'shared_services_wizard_api_key' ) );
			$is_saved = true;
		}
		?>
		<div class="wrap">
			<h1>Shared Services Wizard Settings</h1>

			<?php if ( $is_saved ) { ?>
				<div class="updated settings-error notice is-dismissible" style="margin: 0 0 20px; max-width: 845px;">
					<p><strong>Settings saved successfully.</strong></p>
					<button class="notice-dismiss" type="button">
						<span class="screen-reader-text">Dismiss this notice.</span>
					</button>
				</div>
			<?php } ?>

			<form method="post">
				<table class="form-table">
					<tr>
						<th scope="row"><label for="shared_services_wizard_api_key">Shared Services Wizard API Key</label></th>
						<td>
							<input type="text" name="shared_services_wizard_api_key" id="shared_services_wizard_api_key" value="<?php echo get_option( 'shared_services_wizard_api_key' ); ?>" class="regular-text" />
						</td>
					</tr>
				</table>
				<p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="Save"></p>
			</form>
			<div class="clear"></div>
		</div>
		<?php
	}
    public function admin_scripts() {
	wp_enqueue_style( 'shared-services-wizard-admin-css', SHARED_SERVICES_WIZARD_URL . '/assets/css/admin.css', array(), filemtime( SHARED_SERVICES_WIZARD_DIR . '/assets/css/admin.css' ) );
    }

	public function frontend_scripts() {
	wp_enqueue_style( 'shared-services-wizard-frontend-css', SHARED_SERVICES_WIZARD_URL . '/assets/css/frontend.css', array(), filemtime( SHARED_SERVICES_WIZARD_DIR . '/assets/css/frontend.css' ) );
	wp_enqueue_script( 'shared-services-wizard-frontend-js', SHARED_SERVICES_WIZARD_URL . '/assets/js/frontend.js', array( 'jquery' ), filemtime( SHARED_SERVICES_WIZARD_DIR . '/assets/js/frontend.js' ), true );	
	}

	public function hpos_compatibility() {
		if ( class_exists( 'Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', SHARED_SERVICES_WIZARD_FILE, true );
		}
	}


public function install() {
	global $wpdb;
	$collate = '';
	if ( $wpdb->has_cap( 'collation' ) ) {
		$collate = $wpdb->get_charset_collate();
	}

	$create_tables_query = 'CREATE TABLE if NOT EXISTS `' . $wpdb->prefix . "shared-services-wizard` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`user_id` int(11) NOT NULL,
	`created_time` datetime NOT NULL,
	`updated_time` datetime NOT NULL, 
	PRIMARY KEY( `id` )
	) $collate;";

	$wpdb->query( $create_tables_query );
}

public function maybe_debug() {
	if ( ! isset( $_GET['_debug709'] ) ) {
		return;
	}

	die();
}

    public function get_log_dir( string $handle ) {
		$upload_dir = wp_upload_dir();
		$log_dir    = $upload_dir['basedir'] . '/' . $handle . '-logs';
		wp_mkdir_p( $log_dir );
		return $log_dir;
	}

	public function get_log_file_name( string $handle ) {
		if ( function_exists( 'wp_hash' ) ) {
			$date_suffix = date( 'Y-m-d', time() );
			$hash_suffix = wp_hash( $handle );
			return $this->get_log_dir( $handle ) . '/' . sanitize_file_name( implode( '-', array( $handle, $date_suffix, $hash_suffix ) ) . '.log' );
		}

		return $this->get_log_dir( $handle ) . '/' . $handle . '-' . date( 'Y-m-d', time() ) . '.log';
	}

	public function log( $message ) {
		if ( function_exists( 'wc_get_logger' ) ) {
			wc_get_logger()->debug( print_r( $message, true ), array( 'source' => 'shared-services-wizard' ) );
		} else {
			error_log( date( '[Y-m-d H:i:s e] ' ) . print_r( $message, true ) . PHP_EOL, 3, $this->get_log_file_name( 'shared-services-wizard' ) );
		}
	}

	public static function get_instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}
}

function Shared_Services_Wizard() {
	return Shared_Services_Wizard::get_instance();
}

Shared_Services_Wizard();