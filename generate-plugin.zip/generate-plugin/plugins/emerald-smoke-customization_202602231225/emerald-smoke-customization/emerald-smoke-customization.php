<?php
/**
 * Plugin Name: Emerald Smoke Customization
 * Plugin URI: https://wpstriker.com/plugins
 * Description: Plugin for customization in Emerald Smoke
 * Version: 1.0.0
 * Author: wpstriker
 * Author URI: https://wpstriker.com
 * Text Domain: emerald-smoke-customization
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

define( 'EMERALD_SMOKE_CUSTOMIZATION_VERSION', '1.0.0' );
define( 'EMERALD_SMOKE_CUSTOMIZATION_FILE', __FILE__ );
define( 'EMERALD_SMOKE_CUSTOMIZATION_BASENAME', plugin_basename( __FILE__ ) );
define( 'EMERALD_SMOKE_CUSTOMIZATION_URL', untrailingslashit( plugin_dir_url( __FILE__ ) ) );
define( 'EMERALD_SMOKE_CUSTOMIZATION_DIR', untrailingslashit( plugin_dir_path( __FILE__ ) ) );

require_once EMERALD_SMOKE_CUSTOMIZATION_DIR . '/functions.php';

class Emerald_Smoke_Customization {

	protected static $instance;

	public function __construct() {
	add_action( 'wp_loaded', array( $this, 'maybe_debug' ), 20 ); 
    add_action( 'wp_enqueue_scripts', array( $this, 'frontend_scripts' ) );
    add_action( 'before_woocommerce_init', array( $this, 'hpos_compatibility' ) );
    }

	public function frontend_scripts() {
	wp_enqueue_style( 'emerald-smoke-customization-frontend-css', EMERALD_SMOKE_CUSTOMIZATION_URL . '/assets/css/frontend.css', array(), filemtime( EMERALD_SMOKE_CUSTOMIZATION_DIR . '/assets/css/frontend.css' ) );
	wp_enqueue_script( 'emerald-smoke-customization-frontend-js', EMERALD_SMOKE_CUSTOMIZATION_URL . '/assets/js/frontend.js', array( 'jquery' ), filemtime( EMERALD_SMOKE_CUSTOMIZATION_DIR . '/assets/js/frontend.js' ), true );	
	}

	public function hpos_compatibility() {
		if ( class_exists( 'Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', EMERALD_SMOKE_CUSTOMIZATION_FILE, true );
		}
	}



public function maybe_debug() {
	if ( ! isset( $_GET['_debug765'] ) ) {
		return;
	}

	die();
}

    public function get_log_dir( string $handle ) {
		$upload_dir = wp_upload_dir();
		$log_dir    = $upload_dir['basedir'] . '/' . $handle . '-logs';
		wp_mkdir_p( $log_dir );
		return $log_dir;
	}

	public function get_log_file_name( string $handle ) {
		if ( function_exists( 'wp_hash' ) ) {
			$date_suffix = date( 'Y-m-d', time() );
			$hash_suffix = wp_hash( $handle );
			return $this->get_log_dir( $handle ) . '/' . sanitize_file_name( implode( '-', array( $handle, $date_suffix, $hash_suffix ) ) . '.log' );
		}

		return $this->get_log_dir( $handle ) . '/' . $handle . '-' . date( 'Y-m-d', time() ) . '.log';
	}

	public function log( $message ) {
		if ( function_exists( 'wc_get_logger' ) ) {
			wc_get_logger()->debug( print_r( $message, true ), array( 'source' => 'emerald-smoke-customization' ) );
		} else {
			error_log( date( '[Y-m-d H:i:s e] ' ) . print_r( $message, true ) . PHP_EOL, 3, $this->get_log_file_name( 'emerald-smoke-customization' ) );
		}
	}

	public static function get_instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}
}

function Emerald_Smoke_Customization() {
	return Emerald_Smoke_Customization::get_instance();
}

Emerald_Smoke_Customization();