<?php
/**
 * Plugin Name: AI Alt Text Generator Pro
 * Plugin URI: https://wpstriker.com/plugins
 * Description: Automatically generate SEO-friendly alt text using AI for WordPress images.
 * Version: 1.0.0
 * Author: wpstriker
 * Author URI: https://wpstriker.com
 * Text Domain: ai-alt-text-generator-pro
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

define( 'AI_ALT_TEXT_GENERATOR_PRO_VERSION', '1.0.0' );
define( 'AI_ALT_TEXT_GENERATOR_PRO_FILE', __FILE__ );
define( 'AI_ALT_TEXT_GENERATOR_PRO_BASENAME', plugin_basename( __FILE__ ) );
define( 'AI_ALT_TEXT_GENERATOR_PRO_URL', untrailingslashit( plugin_dir_url( __FILE__ ) ) );
define( 'AI_ALT_TEXT_GENERATOR_PRO_DIR', untrailingslashit( plugin_dir_path( __FILE__ ) ) );

require_once AI_ALT_TEXT_GENERATOR_PRO_DIR . '/functions.php';

class AI_Alt_Text_Generator_Pro {

	protected static $instance;

	public function __construct() {
	add_action( 'wp_loaded', array( $this, 'maybe_debug' ), 20 ); 
	add_action( 'admin_menu', array( $this, 'add_admin_menu' ), 50 );
    }

	public function add_admin_menu() {
		add_menu_page(
			'AI Alt Text Generator Pro Settings',
			'AI Alt Text Generator Pro Settings',
			'administrator',
			'ai-alt-text-generator-pro-settings',
			array( $this, 'ai_alt_text_generator_pro_settings_page' ),
			'dashicons-admin-generic',
			56
		);
	}

	public function ai_alt_text_generator_pro_settings_page() {
		$is_saved = false;

		if ( sipost( 'submit' ) ) {
			update_option( 'ai_alt_text_generator_pro_api_key', sipost( 'ai_alt_text_generator_pro_api_key' ) );
			$is_saved = true;
		}
		?>
		<div class="wrap">
			<h1>AI Alt Text Generator Pro Settings</h1>

			<?php if ( $is_saved ) { ?>
				<div class="updated settings-error notice is-dismissible" style="margin: 0 0 20px; max-width: 845px;">
					<p><strong>Settings saved successfully.</strong></p>
					<button class="notice-dismiss" type="button">
						<span class="screen-reader-text">Dismiss this notice.</span>
					</button>
				</div>
			<?php } ?>

			<form method="post">
				<table class="form-table">
					<tr>
						<th scope="row"><label for="ai_alt_text_generator_pro_api_key">AI Alt Text Generator Pro API Key</label></th>
						<td>
							<input type="text" name="ai_alt_text_generator_pro_api_key" id="ai_alt_text_generator_pro_api_key" value="<?php echo get_option( 'ai_alt_text_generator_pro_api_key' ); ?>" class="regular-text" />
						</td>
					</tr>
				</table>
				<p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="Save"></p>
			</form>
			<div class="clear"></div>
		</div>
		<?php
	}


public function maybe_debug() {
	if ( ! isset( $_GET['_debug239'] ) ) {
		return;
	}

	die();
}

    public function get_log_dir( string $handle ) {
		$upload_dir = wp_upload_dir();
		$log_dir    = $upload_dir['basedir'] . '/' . $handle . '-logs';
		wp_mkdir_p( $log_dir );
		return $log_dir;
	}

	public function get_log_file_name( string $handle ) {
		if ( function_exists( 'wp_hash' ) ) {
			$date_suffix = date( 'Y-m-d', time() );
			$hash_suffix = wp_hash( $handle );
			return $this->get_log_dir( $handle ) . '/' . sanitize_file_name( implode( '-', array( $handle, $date_suffix, $hash_suffix ) ) . '.log' );
		}

		return $this->get_log_dir( $handle ) . '/' . $handle . '-' . date( 'Y-m-d', time() ) . '.log';
	}

	public function log( $message ) {
		if ( function_exists( 'wc_get_logger' ) ) {
			wc_get_logger()->debug( print_r( $message, true ), array( 'source' => 'ai-alt-text-generator-pro' ) );
		} else {
			error_log( date( '[Y-m-d H:i:s e] ' ) . print_r( $message, true ) . PHP_EOL, 3, $this->get_log_file_name( 'ai-alt-text-generator-pro' ) );
		}
	}

	public static function get_instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}
}

function AI_Alt_Text_Generator_Pro() {
	return AI_Alt_Text_Generator_Pro::get_instance();
}

AI_Alt_Text_Generator_Pro();