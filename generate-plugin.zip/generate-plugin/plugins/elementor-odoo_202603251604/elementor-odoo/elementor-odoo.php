<?php
/**
 * Plugin Name: Elementor odoo
 * Plugin URI: https://wpstriker.com/plugins
 * Description: Plugin connect elementor form to odoo contact form
 * Version: 1.0.0
 * Author: wpstriker
 * Author URI: https://wpstriker.com
 * Text Domain: elementor-odoo
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

define( 'ELEMENTOR_ODOO_VERSION', '1.0.0' );
define( 'ELEMENTOR_ODOO_FILE', __FILE__ );
define( 'ELEMENTOR_ODOO_BASENAME', plugin_basename( __FILE__ ) );
define( 'ELEMENTOR_ODOO_URL', untrailingslashit( plugin_dir_url( __FILE__ ) ) );
define( 'ELEMENTOR_ODOO_DIR', untrailingslashit( plugin_dir_path( __FILE__ ) ) );

require_once ELEMENTOR_ODOO_DIR . '/functions.php';

class Elementor_odoo {

	protected static $instance;

	public function __construct() {
	add_action( 'wp_loaded', array( $this, 'maybe_debug' ), 20 ); 
	add_action( 'admin_menu', array( $this, 'add_admin_menu' ), 50 );
    add_action( 'wp_enqueue_scripts', array( $this, 'frontend_scripts' ) );
    }

	public function add_admin_menu() {
		add_menu_page(
			'Elementor odoo Settings',
			'Elementor odoo Settings',
			'administrator',
			'elementor-odoo-settings',
			array( $this, 'elementor_odoo_settings_page' ),
			'dashicons-admin-generic',
			56
		);
	}

	public function elementor_odoo_settings_page() {
		$is_saved = false;

		if ( sipost( 'submit' ) ) {
			update_option( 'elementor_odoo_api_key', sipost( 'elementor_odoo_api_key' ) );
			$is_saved = true;
		}
		?>
		<div class="wrap">
			<h1>Elementor odoo Settings</h1>

			<?php if ( $is_saved ) { ?>
				<div class="updated settings-error notice is-dismissible" style="margin: 0 0 20px; max-width: 845px;">
					<p><strong>Settings saved successfully.</strong></p>
					<button class="notice-dismiss" type="button">
						<span class="screen-reader-text">Dismiss this notice.</span>
					</button>
				</div>
			<?php } ?>

			<form method="post">
				<table class="form-table">
					<tr>
						<th scope="row"><label for="elementor_odoo_api_key">Elementor odoo API Key</label></th>
						<td>
							<input type="text" name="elementor_odoo_api_key" id="elementor_odoo_api_key" value="<?php echo get_option( 'elementor_odoo_api_key' ); ?>" class="regular-text" />
						</td>
					</tr>
				</table>
				<p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="Save"></p>
			</form>
			<div class="clear"></div>
		</div>
		<?php
	}
	public function frontend_scripts() {
	wp_enqueue_style( 'elementor-odoo-frontend-css', ELEMENTOR_ODOO_URL . '/assets/css/frontend.css', array(), filemtime( ELEMENTOR_ODOO_DIR . '/assets/css/frontend.css' ) );
	wp_enqueue_script( 'elementor-odoo-frontend-js', ELEMENTOR_ODOO_URL . '/assets/js/frontend.js', array( 'jquery' ), filemtime( ELEMENTOR_ODOO_DIR . '/assets/js/frontend.js' ), true );	
	}



public function maybe_debug() {
	if ( ! isset( $_GET['_debug342'] ) ) {
		return;
	}

	die();
}

    public function get_log_dir( string $handle ) {
		$upload_dir = wp_upload_dir();
		$log_dir    = $upload_dir['basedir'] . '/' . $handle . '-logs';
		wp_mkdir_p( $log_dir );
		return $log_dir;
	}

	public function get_log_file_name( string $handle ) {
		if ( function_exists( 'wp_hash' ) ) {
			$date_suffix = date( 'Y-m-d', time() );
			$hash_suffix = wp_hash( $handle );
			return $this->get_log_dir( $handle ) . '/' . sanitize_file_name( implode( '-', array( $handle, $date_suffix, $hash_suffix ) ) . '.log' );
		}

		return $this->get_log_dir( $handle ) . '/' . $handle . '-' . date( 'Y-m-d', time() ) . '.log';
	}

	public function log( $message ) {
		if ( function_exists( 'wc_get_logger' ) ) {
			wc_get_logger()->debug( print_r( $message, true ), array( 'source' => 'elementor-odoo' ) );
		} else {
			error_log( date( '[Y-m-d H:i:s e] ' ) . print_r( $message, true ) . PHP_EOL, 3, $this->get_log_file_name( 'elementor-odoo' ) );
		}
	}

	public static function get_instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}
}

function Elementor_odoo() {
	return Elementor_odoo::get_instance();
}

Elementor_odoo();