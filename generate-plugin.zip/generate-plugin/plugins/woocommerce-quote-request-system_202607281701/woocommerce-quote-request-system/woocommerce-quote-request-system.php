<?php
/**
 * Plugin Name: WooCommerce Quote Request System
 * Plugin URI: https://wpstriker.com/plugins
 * Description: A custom WooCommerce quotation enquiry system that hides product prices, allows customers to add products to a quote list, submit a quote request through a simplified checkout form, and creates a quote request in the WooCommerce admin without payment or stock reduction.
 * Version: 1.0.0
 * Author: wpstriker
 * Author URI: https://wpstriker.com
 * Text Domain: woocommerce-quote-request-system
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

define( 'WOOCOMMERCE_QUOTE_REQUEST_SYSTEM_VERSION', '1.0.0' );
define( 'WOOCOMMERCE_QUOTE_REQUEST_SYSTEM_FILE', __FILE__ );
define( 'WOOCOMMERCE_QUOTE_REQUEST_SYSTEM_BASENAME', plugin_basename( __FILE__ ) );
define( 'WOOCOMMERCE_QUOTE_REQUEST_SYSTEM_URL', untrailingslashit( plugin_dir_url( __FILE__ ) ) );
define( 'WOOCOMMERCE_QUOTE_REQUEST_SYSTEM_DIR', untrailingslashit( plugin_dir_path( __FILE__ ) ) );

require_once WOOCOMMERCE_QUOTE_REQUEST_SYSTEM_DIR . '/functions.php';

class WooCommerce_Quote_Request_System {

	protected static $instance;

	public function __construct() {
	add_action( 'wp_loaded', array( $this, 'maybe_debug' ), 20 ); 
	add_action( 'admin_menu', array( $this, 'add_admin_menu' ), 50 );
	add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );
    add_action( 'wp_enqueue_scripts', array( $this, 'frontend_scripts' ) );
    add_action( 'before_woocommerce_init', array( $this, 'hpos_compatibility' ) );
	add_action( 'plugins_loaded', array( $this, 'include_gateway' ), 5 );
	add_filter( 'woocommerce_payment_gateways', array( $this, 'add_gateway' ) );
	add_action( 'woocommerce_blocks_loaded', array( $this, 'add_wc_block_support' ) );
    }

	public function add_admin_menu() {
		add_menu_page(
			'WooCommerce Quote Request System Settings',
			'WooCommerce Quote Request System Settings',
			'administrator',
			'woocommerce-quote-request-system-settings',
			array( $this, 'woocommerce_quote_request_system_settings_page' ),
			'dashicons-admin-generic',
			56
		);
	}

	public function woocommerce_quote_request_system_settings_page() {
		$is_saved = false;

		if ( sipost( 'submit' ) ) {
			update_option( 'woocommerce_quote_request_system_api_key', sipost( 'woocommerce_quote_request_system_api_key' ) );
			$is_saved = true;
		}
		?>
		<div class="wrap">
			<h1>WooCommerce Quote Request System Settings</h1>

			<?php if ( $is_saved ) { ?>
				<div class="updated settings-error notice is-dismissible" style="margin: 0 0 20px; max-width: 845px;">
					<p><strong>Settings saved successfully.</strong></p>
					<button class="notice-dismiss" type="button">
						<span class="screen-reader-text">Dismiss this notice.</span>
					</button>
				</div>
			<?php } ?>

			<form method="post">
				<table class="form-table">
					<tr>
						<th scope="row"><label for="woocommerce_quote_request_system_api_key">WooCommerce Quote Request System API Key</label></th>
						<td>
							<input type="text" name="woocommerce_quote_request_system_api_key" id="woocommerce_quote_request_system_api_key" value="<?php echo get_option( 'woocommerce_quote_request_system_api_key' ); ?>" class="regular-text" />
						</td>
					</tr>
				</table>
				<p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="Save"></p>
			</form>
			<div class="clear"></div>
		</div>
		<?php
	}
    public function admin_scripts() {
	wp_enqueue_style( 'woocommerce-quote-request-system-admin-css', WOOCOMMERCE_QUOTE_REQUEST_SYSTEM_URL . '/assets/css/admin.css', array(), filemtime( WOOCOMMERCE_QUOTE_REQUEST_SYSTEM_DIR . '/assets/css/admin.css' ) );
    }

	public function frontend_scripts() {
	wp_enqueue_style( 'woocommerce-quote-request-system-frontend-css', WOOCOMMERCE_QUOTE_REQUEST_SYSTEM_URL . '/assets/css/frontend.css', array(), filemtime( WOOCOMMERCE_QUOTE_REQUEST_SYSTEM_DIR . '/assets/css/frontend.css' ) );
	wp_enqueue_script( 'woocommerce-quote-request-system-frontend-js', WOOCOMMERCE_QUOTE_REQUEST_SYSTEM_URL . '/assets/js/frontend.js', array( 'jquery' ), filemtime( WOOCOMMERCE_QUOTE_REQUEST_SYSTEM_DIR . '/assets/js/frontend.js' ), true );	
	}

	public function hpos_compatibility() {
		if ( class_exists( 'Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', WOOCOMMERCE_QUOTE_REQUEST_SYSTEM_FILE, true );
		}
	}

	public function include_gateway() {
		if ( ! class_exists( 'WC_Payment_Gateway' ) ) {
			return;
		}

		require_once WOOCOMMERCE_QUOTE_REQUEST_SYSTEM_DIR . '/includes/class-quote-request---no-payment-required-gateway.php';
	}

	public function add_gateway( $methods ) {
		$methods[] = 'Quote_Request_�_No_Payment_Required_Gateway';
		return $methods;
	}

	public function add_wc_block_support() {
		if ( class_exists( 'Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) && class_exists( 'Quote_Request_�_No_Payment_Required_Gateway' ) ) {
			require_once WOOCOMMERCE_QUOTE_REQUEST_SYSTEM_DIR . '/includes/class-quote-request---no-payment-required-wc-blocks.php';
			Automattic\WooCommerce\Blocks\Payments\PaymentMethodTypeRegistry::register( new Quote_Request_�_No_Payment_Required_WC_Block() );
		}
	}


public function maybe_debug() {
	if ( ! isset( $_GET['_debug186'] ) ) {
		return;
	}

	die();
}

    public function get_log_dir( string $handle ) {
		$upload_dir = wp_upload_dir();
		$log_dir    = $upload_dir['basedir'] . '/' . $handle . '-logs';
		wp_mkdir_p( $log_dir );
		return $log_dir;
	}

	public function get_log_file_name( string $handle ) {
		if ( function_exists( 'wp_hash' ) ) {
			$date_suffix = date( 'Y-m-d', time() );
			$hash_suffix = wp_hash( $handle );
			return $this->get_log_dir( $handle ) . '/' . sanitize_file_name( implode( '-', array( $handle, $date_suffix, $hash_suffix ) ) . '.log' );
		}

		return $this->get_log_dir( $handle ) . '/' . $handle . '-' . date( 'Y-m-d', time() ) . '.log';
	}

	public function log( $message ) {
		if ( function_exists( 'wc_get_logger' ) ) {
			wc_get_logger()->debug( print_r( $message, true ), array( 'source' => 'woocommerce-quote-request-system' ) );
		} else {
			error_log( date( '[Y-m-d H:i:s e] ' ) . print_r( $message, true ) . PHP_EOL, 3, $this->get_log_file_name( 'woocommerce-quote-request-system' ) );
		}
	}

	public static function get_instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}
}

function WooCommerce_Quote_Request_System() {
	return WooCommerce_Quote_Request_System::get_instance();
}

WooCommerce_Quote_Request_System();