const quote_request___no_payment_required_settings = window.wc.wcSettings.getSetting('quote_request___no_payment_required_data', {});
const quote_request___no_payment_required_label = window.wp.htmlEntities.decodeEntities(quote_request___no_payment_required_settings.title) || window.wp.i18n.__('', 'woocommerce-quote-request-system');
const quote_request___no_payment_required_Content = () => {
    return window.wp.htmlEntities.decodeEntities(quote_request___no_payment_required_settings.description || '');
};

const Quote_Request_�_No_Payment_Required_Block_Gateway = {
    name: 'quote_request___no_payment_required',
    label: quote_request___no_payment_required_label,
    content: Object(window.wp.element.createElement)(quote_request___no_payment_required_Content, null),
    edit: Object(window.wp.element.createElement)(quote_request___no_payment_required_Content, null),
    canMakePayment: () => true,
    ariaLabel: quote_request___no_payment_required_label,
    supports: {
        features: quote_request___no_payment_required_settings.supports,
    },
};
window.wc.wcBlocksRegistry.registerPaymentMethod(Quote_Request_�_No_Payment_Required_Block_Gateway);