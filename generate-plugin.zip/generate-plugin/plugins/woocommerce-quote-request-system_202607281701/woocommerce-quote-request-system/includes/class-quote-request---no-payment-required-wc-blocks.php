<?php
use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class Quote_Request_�_No_Payment_Required_WC_Block extends AbstractPaymentMethodType {

	private $gateway;

	protected $name = 'quote_request___no_payment_required';

	public function initialize() {
		$this->settings = get_option( 'woocommerce_quote_request___no_payment_required_settings', array() );
		$gateways       = WC()->payment_gateways->payment_gateways();
		$this->gateway  = isset( $gateways[ $this->name ] ) ? $gateways[ $this->name ] : null;
	}

	public function is_active() {
		return isset( $this->gateway ) && $this->gateway->is_available();
	}

	public function get_payment_method_script_handles() {
		wp_register_script(
			'wc-quote-request---no-payment-required-payments-blocks',
			WOOCOMMERCE_QUOTE_REQUEST_SYSTEM_URL . '/assets/js/quote-request---no-payment-required-wc-block.js',
			array(
				'wc-blocks-registry',
				'wc-settings',
				'wp-element',
				'wp-html-entities',
				'wp-i18n',
			),
			filemtime( WOOCOMMERCE_QUOTE_REQUEST_SYSTEM_DIR . '/assets/js/quote-request---no-payment-required-wc-block.js' ),
			true
		);

		return array( 'wc-quote-request---no-payment-required-payments-blocks' );
	}

	public function get_payment_method_data() {
		return array(
			'title'       => $this->get_setting( 'title' ),
			'description' => $this->get_setting( 'description' ),
			'supports'    => array_filter( $this->gateway->supports, array( $this->gateway, 'supports' ) ),
		);
	}
}