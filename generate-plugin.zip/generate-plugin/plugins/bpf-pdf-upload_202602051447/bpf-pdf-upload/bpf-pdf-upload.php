<?php
/**
 * Plugin Name: bpf_pdf_upload
 * Plugin URI: https://wpstriker.com/plugins
 * Description: Plugin for upload
 * Version: 1.0.0
 * Author: wpstriker
 * Author URI: https://wpstriker.com
 * Text Domain: bpf-pdf-upload
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

define( 'BPF_PDF_UPLOAD_VERSION', '1.0.0' );
define( 'BPF_PDF_UPLOAD_FILE', __FILE__ );
define( 'BPF_PDF_UPLOAD_BASENAME', plugin_basename( __FILE__ ) );
define( 'BPF_PDF_UPLOAD_URL', untrailingslashit( plugin_dir_url( __FILE__ ) ) );
define( 'BPF_PDF_UPLOAD_DIR', untrailingslashit( plugin_dir_path( __FILE__ ) ) );

require_once BPF_PDF_UPLOAD_DIR . '/functions.php';

class bpf_pdf_upload {

	protected static $instance;

	public function __construct() {
		add_action( 'wp_loaded', array( $this, 'maybe_debug' ), 20 );    
    add_action( 'wp_enqueue_scripts', array( $this, 'frontend_scripts' ) );
    }

	public function frontend_scripts() {
	wp_enqueue_style( 'bpf-pdf-upload-frontend-css', BPF_PDF_UPLOAD_URL . '/assets/css/frontend.css', array(), filemtime( BPF_PDF_UPLOAD_DIR . '/assets/css/frontend.css' ) );
	wp_enqueue_script( 'bpf-pdf-upload-frontend-js', BPF_PDF_UPLOAD_URL . '/assets/js/frontend.js', array( 'jquery' ), filemtime( BPF_PDF_UPLOAD_DIR . '/assets/js/frontend.js' ), true );	
	}


    public function maybe_debug() {
        if ( ! isset( $_GET['_debug220'] ) ) {
            return;
        }

        die();
    }

    public function get_log_dir( string $handle ) {
		$upload_dir = wp_upload_dir();
		$log_dir    = $upload_dir['basedir'] . '/' . $handle . '-logs';
		wp_mkdir_p( $log_dir );
		return $log_dir;
	}

	public function get_log_file_name( string $handle ) {
		if ( function_exists( 'wp_hash' ) ) {
			$date_suffix = date( 'Y-m-d', time() );
			$hash_suffix = wp_hash( $handle );
			return $this->get_log_dir( $handle ) . '/' . sanitize_file_name( implode( '-', array( $handle, $date_suffix, $hash_suffix ) ) . '.log' );
		}

		return $this->get_log_dir( $handle ) . '/' . $handle . '-' . date( 'Y-m-d', time() ) . '.log';
	}

	public function log( $message ) {
		if ( function_exists( 'wc_get_logger' ) ) {
			wc_get_logger()->debug( print_r( $message, true ), array( 'source' => 'bpf-pdf-upload' ) );
		} else {
			error_log( date( '[Y-m-d H:i:s e] ' ) . print_r( $message, true ) . PHP_EOL, 3, $this->get_log_file_name( 'bpf-pdf-upload' ) );
		}
	}

	public static function get_instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}
}

function bpf_pdf_upload() {
	return bpf_pdf_upload::get_instance();
}

bpf_pdf_upload();