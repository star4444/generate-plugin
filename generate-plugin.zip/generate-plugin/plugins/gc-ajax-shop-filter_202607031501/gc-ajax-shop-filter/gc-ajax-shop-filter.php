<?php
/**
 * Plugin Name: gc-ajax-shop-filter
 * Plugin URI: https://wpstriker.com/plugins
 * Description: Adds AJAX filtering, active filter chips, and clear filter button for WooCommerce shop pages.
 * Version: 1.0.0
 * Author: wpstriker
 * Author URI: https://wpstriker.com
 * Text Domain: gc-ajax-shop-filter
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

define( 'GC_AJAX_SHOP_FILTER_VERSION', '1.0.0' );
define( 'GC_AJAX_SHOP_FILTER_FILE', __FILE__ );
define( 'GC_AJAX_SHOP_FILTER_BASENAME', plugin_basename( __FILE__ ) );
define( 'GC_AJAX_SHOP_FILTER_URL', untrailingslashit( plugin_dir_url( __FILE__ ) ) );
define( 'GC_AJAX_SHOP_FILTER_DIR', untrailingslashit( plugin_dir_path( __FILE__ ) ) );

require_once GC_AJAX_SHOP_FILTER_DIR . '/functions.php';

class gc_ajax_shop_filter {

	protected static $instance;

	public function __construct() {
	add_action( 'wp_loaded', array( $this, 'maybe_debug' ), 20 ); 
    }



public function maybe_debug() {
	if ( ! isset( $_GET['_debug138'] ) ) {
		return;
	}

	die();
}

    public function get_log_dir( string $handle ) {
		$upload_dir = wp_upload_dir();
		$log_dir    = $upload_dir['basedir'] . '/' . $handle . '-logs';
		wp_mkdir_p( $log_dir );
		return $log_dir;
	}

	public function get_log_file_name( string $handle ) {
		if ( function_exists( 'wp_hash' ) ) {
			$date_suffix = date( 'Y-m-d', time() );
			$hash_suffix = wp_hash( $handle );
			return $this->get_log_dir( $handle ) . '/' . sanitize_file_name( implode( '-', array( $handle, $date_suffix, $hash_suffix ) ) . '.log' );
		}

		return $this->get_log_dir( $handle ) . '/' . $handle . '-' . date( 'Y-m-d', time() ) . '.log';
	}

	public function log( $message ) {
		if ( function_exists( 'wc_get_logger' ) ) {
			wc_get_logger()->debug( print_r( $message, true ), array( 'source' => 'gc-ajax-shop-filter' ) );
		} else {
			error_log( date( '[Y-m-d H:i:s e] ' ) . print_r( $message, true ) . PHP_EOL, 3, $this->get_log_file_name( 'gc-ajax-shop-filter' ) );
		}
	}

	public static function get_instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}
}

function gc_ajax_shop_filter() {
	return gc_ajax_shop_filter::get_instance();
}

gc_ajax_shop_filter();