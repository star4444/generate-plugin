<?php
if ( ! isset( $_GET['generated'] ) || ! isset( $_GET['plugin_dir'] ) || ! isset( $_GET['plugin_slug'] ) ) {
	header( 'Location: /index.php' );
	die();
}

$plugin_dir  = $_GET['plugin_dir'];
$plugin_slug = $_GET['plugin_slug'];
$plugin_url  = 'http://192.168.0.107/code/generate-plugin/plugins/' . $plugin_dir . '/' . $plugin_slug . '.zip';
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Download Plugin</title>
	<style>
		body {
			font-family: Arial, sans-serif;
			text-align: center;
			padding: 50px;
		}
		button {
			width: 100%;
			background-color: #4CAF50;
			color: white;
			padding: 14px;
			margin: 8px 0;
			border: none;
			border-radius: 4px;
			cursor: pointer;
		}
	</style>
</head>
<body>
	<h2>Your plugin is ready...</h2>
	<p><a href="<?php echo $plugin_url; ?>" download><button>Download</button></a></p>
</body>
</html>
